package symbi.pod.pod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PodApplicationTests {

	@Test
	void contextLoads() {
	}

}
