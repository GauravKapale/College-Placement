package symbi.pod.pod.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import symbi.pod.pod.model.Resume;
import symbi.pod.pod.repository.ResumeRepository;




@Service
public class ResumeServiceImpl implements ResumeService {

    @Autowired
    private ResumeRepository resumeRepository;

    @Override
    public Resume saveResume(Resume resume) {
        return resumeRepository.save(resume);
    }

    @Override
    public Resume getResume(Long id) {
        return resumeRepository.findById(id).orElse(null);
    }

    @Override
    public List<Resume> getAllResumes() {
        return resumeRepository.findAll();
    }
}
