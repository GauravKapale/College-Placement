package symbi.pod.pod.model;

public class Opportunity {

}
