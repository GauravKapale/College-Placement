package symbi.pod.pod.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "applications")
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "job_id")
    private Job job;
    
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    private String status;

    private Long getId() {
		return id;
	}

	private void setId(Long id) {
		this.id = id;
	}

	private Job getJob() {
		return job;
	}

	private void setJob(Job job) {
		this.job = job;
	}

	private User getUser() {
		return user;
	}

	private void setUser(User user) {
		this.user = user;
	}

	private String getStatus() {
		return status;
	}

	private void setStatus(String status) {
		this.status = status;
	}

	public Application(Long id, Job job, User user, String status) {
		super();
		this.id = id;
		this.job = job;
		this.user = user;
		this.status = status;
	}

	

    // Getters, setters, and constructors
}