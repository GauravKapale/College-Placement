package symbi.pod.pod.service;

import java.util.List;

import symbi.pod.pod.model.Resume;




public interface ResumeService {
    Resume saveResume(Resume resume);
    Resume getResume(Long id);
    List<Resume> getAllResumes();
}
