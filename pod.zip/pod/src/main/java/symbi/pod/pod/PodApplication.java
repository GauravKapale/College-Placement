package symbi.pod.pod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PodApplication {

	public static void main(String[] args) {
		SpringApplication.run(PodApplication.class, args);
	}

}
