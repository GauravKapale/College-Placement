package symbi.pod.pod.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import symbi.pod.pod.model.ForumPost;
import symbi.pod.pod.repository.ForumPostRepository;



@Service
public class ForumPostService {

    @Autowired
    private ForumPostRepository forumPostRepository;

    public List<ForumPost> getAllPosts() {
        return forumPostRepository.findAll();
    }

    public ForumPost getPostById(Long id) {
        return forumPostRepository.findById(id).orElse(null);
    }

    public ForumPost savePost(ForumPost post) {
        return forumPostRepository.save(post);
    }

    public void deletePost(Long id) {
        forumPostRepository.deleteById(id);
    }
}
