package symbi.pod.pod.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import symbi.pod.pod.model.User;

@RestController
public class SignupController {

    @PostMapping("/api/signup")
    public ResponseEntity<String> signup(@RequestBody User user) {
        // Process the sign-up data
        System.out.println("Username: " + user.getUsername());
        System.out.println("Password: " + user.getPassword());

        // Here you can add your user registration logic

        return ResponseEntity.ok("Signup successful");
    }
}