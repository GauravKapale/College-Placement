package symbi.pod.pod.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import symbi.pod.pod.model.Offer;
import symbi.pod.pod.model.User;
import symbi.pod.pod.repository.OfferRepository;



@RestController
@RequestMapping("/api/offers")
public class OfferController {
    @Autowired
    private OfferRepository offerRepository;

    @GetMapping
    public ResponseEntity<Iterable<Offer>> getUserOffers(@RequestParam("userId") Long userId) {
        User user = new User();
        user.setId(userId);
        return ResponseEntity.ok(offerRepository.findByApplication_User(user));
    }
}
