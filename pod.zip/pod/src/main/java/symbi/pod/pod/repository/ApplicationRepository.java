package symbi.pod.pod.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import symbi.pod.pod.model.Application;
import symbi.pod.pod.model.User;



@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
	Iterable<Application> findByUser(User user);

}
