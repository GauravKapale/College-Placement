package symbi.pod.pod.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import symbi.pod.pod.model.Opportunity;
import symbi.pod.pod.repository.OpportunityRepository;

@RestController
@RequestMapping("/api/opportunities")
public class OpportunityController {
    @Autowired
    private OpportunityRepository opportunityRepository;

    @GetMapping
    public ResponseEntity<Iterable<Opportunity>> getAllOpportunities() {
        return ResponseEntity.ok(opportunityRepository.findAll());
    }
}
