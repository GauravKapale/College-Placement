package symbi.pod.pod.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "jobs")
public class Job {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String companyName;

    @Column(nullable = false)
    private String criteria;

    @Column(nullable = false)
    private double salary;

    @Column(nullable = false)
    private String description;

    @Column(nullable = false)
    private String applyLink;

	private Long getId() {
		return id;
	}

	private void setId(Long id) {
		this.id = id;
	}

	private String getCompanyName() {
		return companyName;
	}

	private void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	private String getCriteria() {
		return criteria;
	}

	private void setCriteria(String criteria) {
		this.criteria = criteria;
	}

	private double getSalary() {
		return salary;
	}

	private void setSalary(double salary) {
		this.salary = salary;
	}

	private String getDescription() {
		return description;
	}

	private void setDescription(String description) {
		this.description = description;
	}

	private String getApplyLink() {
		return applyLink;
	}

	private void setApplyLink(String applyLink) {
		this.applyLink = applyLink;
	}

    // Getters, setters, and constructors
    
    
}