package symbi.pod.pod.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import symbi.pod.pod.model.ForumPost;


@Repository
public interface ForumPostRepository extends JpaRepository<ForumPost, Long> {
	
}