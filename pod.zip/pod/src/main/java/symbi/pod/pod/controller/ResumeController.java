package symbi.pod.pod.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import symbi.pod.pod.model.Resume;
import symbi.pod.pod.repository.ResumeRepository;



@RestController
@RequestMapping("/api/resumes")
public class ResumeController {
    private static final String UPLOAD_DIR = "uploads/";

    @Autowired
    private ResumeRepository resumeRepository;

    @GetMapping
    public ResponseEntity<Iterable<Resume>> getAllResumes() {
        return ResponseEntity.ok(resumeRepository.findAll());
    }

    @PostMapping
    public ResponseEntity<Resume> uploadResume(@RequestParam("file") MultipartFile file) {
        try {
            String fileName = file.getOriginalFilename();
            String filePath = UPLOAD_DIR + fileName;
            Path path = Paths.get(filePath);

            Files.copy(file.getInputStream(), path);

            Resume resume = new Resume();
            resume.setFileName(fileName);
            resume.setFilePath(filePath);

            Resume savedResume = resumeRepository.save(resume);
            return ResponseEntity.status(HttpStatus.CREATED).body(savedResume);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}