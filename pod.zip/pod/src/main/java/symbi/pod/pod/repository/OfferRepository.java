package symbi.pod.pod.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import symbi.pod.pod.model.Offer;
import symbi.pod.pod.model.User;


@Repository
public interface OfferRepository extends JpaRepository<Offer, Long> {
    Iterable<Offer> findByApplication_User(User user);

}
